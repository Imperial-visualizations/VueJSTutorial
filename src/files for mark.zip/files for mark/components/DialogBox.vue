<template>
    <div class="dialog-box">
        <h1>Dialog message</h1>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.dialog-box{
    background-color: rgb(163, 218, 252);
    border: 4px solid skyblue;
    margin: 40px;

}
.dialog-box h1{
    font-size: 16pt;
}
</style>